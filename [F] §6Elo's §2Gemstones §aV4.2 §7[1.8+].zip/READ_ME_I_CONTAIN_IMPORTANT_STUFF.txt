THIS PACK IS NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG.

Hello, thank you for using my Texture-Pack!
If you have any questions or found a bug please let me know!
Hope you enjoy ^^

I mark my packs with different prefixes in their name. That does NOT impact the pack in any way, just saying.
The packs are marked with the following prefixes:

[N] = New-Version; I am trying some random stuff for a pack
[T] = Test-Version; I am working on parts of a pack but it's not finished yet
[F] = Finished-Version; I have finished a pack and ask someone to test it before I release the pack
[R] = Released-Version; I have finished testing the pack. This prefix is used for (nearly) all packs you can find in my folder

Examples:
[N] Elo's Example Pack [1.8.+]
[T] Elo's Example Pack [1.8.+]
[F] Elo's Example Pack [1.8.+]
[R] Elo's Example Pack [1.8.+]


Contact Me:
My MC-IngameName   Eloldur
My Discord-Tag	Eloldur | Raphael#4927
My Discord Server  discord.gg/8C3h9MmtdW


Find My Packs:
Google-Drive    https://drive.google.com/drive/folders/1gocosM2i2WL0CIgSvkBAVccbhqTtu0sI?usp=sharing



This note was created on 08.02.2022 10:30 PM
If you find another note that's newer than this
I might have updated and added some stuff :D


Rule-Stuff (woohooo!):

* You are allowed to use my packs for your own without asking for permission or stuff (obv, lol)

* You are allowed to use my packs in videos/streams/screenshots/etc., if you link my google-folder
* You are allowed to share my packs with your friends by sending them the link or the textures
* You are allowed to edit my packs as long as you wont inject harmful content or claim it as 100% of your work

* You are NOT allowed to claim any of my packs or work as yours
* You are NOT allowed to re-upload my packs on any platform (doesn't matter if you have changed a thing or not)
* You are NOT allowed to use my packs or work in general for any harmful content
* You are NOT allowed to sell my packs or work in any form

* If you want to create and publish an edited version of my packs, ask for my permission and give credits
* If you are not sure if something you want to do with my packs or work is okay, contact me via Discord or Email